from django.apps import AppConfig


class AuthenticationConfig(AppConfig):
    name = 'agape_authentication'
